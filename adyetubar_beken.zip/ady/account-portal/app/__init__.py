"""Standalone account portal app."""
