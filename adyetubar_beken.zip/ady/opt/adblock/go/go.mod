module github.com/faisin/beken/opt/adblock/go

go 1.22
