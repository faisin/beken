module github.com/faisin/beken/opt/edge/go

go 1.22
