package observability

import (
	"context"
	"encoding/json"
	"errors"
	"log"
	"net"
	"net/http"
	"sync"
	"time"

	edgeruntime "github.com/faisin/beken/opt/edge/go/internal/runtime"
)

type Server struct {
	logger    *log.Logger
	collector *Collector
	configFn  func() edgeruntime.Config
	stateFn   func() ListenerSnapshot
	backendFn func(edgeruntime.Config) map[string]BackendHealthSnapshot
	abuseFn   func() *AbuseSnapshot

	mu     sync.Mutex
	addr   string
	ln     net.Listener
	srv    *http.Server
	active bool
}

func NewServer(
	logger *log.Logger,
	collector *Collector,
	configFn func() edgeruntime.Config,
	stateFn func() ListenerSnapshot,
	backendFn func(edgeruntime.Config) map[string]BackendHealthSnapshot,
	abuseFn func() *AbuseSnapshot,
) *Server {
	return &Server{
		logger:    logger,
		collector: collector,
		configFn:  configFn,
		stateFn:   stateFn,
		backendFn: backendFn,
		abuseFn:   abuseFn,
	}
}

func (s *Server) Configure(cfg edgeruntime.Config) error {
	if !cfg.MetricsEnabled {
		oldSrv, oldLn, oldAddr := s.swap(nil, nil, "")
		if oldSrv != nil && s.logger != nil {
			s.logger.Printf("edge-mux metrics listener disabled (was %s)", oldAddr)
		}
		return shutdownHTTPServer(oldSrv, oldLn)
	}

	if s.sameActiveAddr(cfg.MetricsAddr()) {
		return nil
	}
	if s.sameInactiveAddr(cfg.MetricsAddr()) {
		oldSrv, oldLn, oldAddr := s.swap(nil, nil, "")
		if err := shutdownHTTPServer(oldSrv, oldLn); err != nil {
			return err
		}
		if oldSrv != nil && s.logger != nil {
			s.logger.Printf("edge-mux metrics listener cleared stale state on %s", oldAddr)
		}
	}

	handler := s.newHandler()
	listener, err := net.Listen("tcp", cfg.MetricsAddr())
	if err != nil {
		return err
	}
	server := &http.Server{
		Handler:           handler,
		ReadHeaderTimeout: 5 * time.Second,
	}

	oldSrv, oldLn, oldAddr := s.swap(server, listener, cfg.MetricsAddr())
	if err := shutdownHTTPServer(oldSrv, oldLn); err != nil && s.logger != nil {
		s.logger.Printf("edge-mux metrics shutdown failed addr=%s: %v", oldAddr, err)
	}

	if s.logger != nil && oldAddr != cfg.MetricsAddr() {
		s.logger.Printf("edge-mux metrics listener ready on %s", cfg.MetricsAddr())
	}
	go s.serve(server, listener, cfg.MetricsAddr())
	return nil
}

func (s *Server) Addr() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.addr
}

func (s *Server) Active() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.active
}

func (s *Server) Close() error {
	oldSrv, oldLn, _ := s.swap(nil, nil, "")
	return shutdownHTTPServer(oldSrv, oldLn)
}

func (s *Server) serve(server *http.Server, listener net.Listener, addr string) {
	if err := server.Serve(listener); err != nil && !errors.Is(err, http.ErrServerClosed) {
		s.markInactive(server, listener)
		if s.logger != nil {
			s.logger.Printf("edge-mux metrics server failed addr=%s: %v", addr, err)
		}
	}
}

func (s *Server) swap(server *http.Server, listener net.Listener, addr string) (*http.Server, net.Listener, string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	oldSrv := s.srv
	oldLn := s.ln
	oldAddr := s.addr
	s.srv = server
	s.ln = listener
	s.addr = addr
	s.active = server != nil
	return oldSrv, oldLn, oldAddr
}

func (s *Server) markInactive(server *http.Server, listener net.Listener) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.srv != server || s.ln != listener {
		return
	}
	s.active = false
}

func (s *Server) sameActiveAddr(addr string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.active && s.addr == addr && s.srv != nil && s.ln != nil
}

func (s *Server) sameInactiveAddr(addr string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return !s.active && s.addr == addr && (s.srv != nil || s.ln != nil)
}

func (s *Server) newHandler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		_, _ = w.Write([]byte("ok\n"))
	})
	mux.HandleFunc("/status", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		cfg := edgeruntime.Config{}
		if s.configFn != nil {
			cfg = s.configFn()
		}
		listeners := ListenerSnapshot{}
		if s.stateFn != nil {
			listeners = s.stateFn()
		}
		var backends map[string]BackendHealthSnapshot
		if s.backendFn != nil {
			backends = s.backendFn(cfg)
		}
		var abuse *AbuseSnapshot
		if s.abuseFn != nil {
			abuse = s.abuseFn()
		}
		status := s.collector.Snapshot(cfg, listeners, backends, abuse)
		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		enc := json.NewEncoder(w)
		enc.SetIndent("", "  ")
		_ = enc.Encode(status)
	})
	mux.HandleFunc("/metrics", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		cfg := edgeruntime.Config{}
		if s.configFn != nil {
			cfg = s.configFn()
		}
		listeners := ListenerSnapshot{}
		if s.stateFn != nil {
			listeners = s.stateFn()
		}
		w.Header().Set("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
		_, _ = w.Write(s.collector.RenderPrometheus(cfg, listeners))
	})
	return mux
}

func shutdownHTTPServer(server *http.Server, listener net.Listener) error {
	if server == nil {
		if listener != nil {
			return listener.Close()
		}
		return nil
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	err := server.Shutdown(ctx)
	if listener != nil {
		closeErr := listener.Close()
		if closeErr != nil && !errors.Is(closeErr, net.ErrClosed) && err == nil {
			err = closeErr
		}
	}
	return err
}
